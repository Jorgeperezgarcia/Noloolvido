import 'package:flutter/material.dart';

void main() => runApp(NoLoOlvidoApp());

class NoLoOlvidoApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('NoLoOlvido')),
        body: Center(child: Text('App base lista para compilar')),
      ),
    );
  }
}
